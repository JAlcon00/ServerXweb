import {Router} from "express";
import { 
crearUsuario, 
obtenerUsuarios, 
obtenerUsuariobyId,
actualizarUsuario,
eliminarUsuario,
loginUsuario,
omitirPassword


} from "../controllers/usuarioController";
import { loginLimiter } from "../middleware/rateLimiter";

const router = Router();

//Rutas publicas
router.post("/", crearUsuario);
router.get("/", obtenerUsuarios);  
router.get("/:id", obtenerUsuariobyId);
//Rutas privadas
router.put("/:id", actualizarUsuario);
router.delete("/:id", eliminarUsuario);

//Rutas de autenticación
router.post("/login", loginUsuario, loginLimiter);
router.put("/:id", omitirPassword);

export default router;