import { Request, Response, NextFunction } from "express";
import { UsuarioModel } from '../models/usuarioModels';
import { loginLimiter } from '../middleware/rateLimiter';
// Crear un nuevo usuario
export const crearUsuario = async (req: Request, res: Response) => {
    try {
        const usuario = await UsuarioModel.crear(req.body);
        // Omitir el password en la respuesta
        const { password, ...usuarioSinPassword } = usuario;
        res.status(201).json(usuarioSinPassword);
    } catch (error) {
        res.status(500).json({ message: 'Error al crear el usuario', error });
    }
};

// Obtener todos los usuarios
export const obtenerUsuarios = async (req: Request, res: Response) => {
    try {
        const usuarios = await UsuarioModel.obtenerTodos();
        // Omitir passwords en la respuesta
        const usuariosSinPassword = usuarios.map(({ password, ...rest }) => rest);
        res.status(200).json(usuariosSinPassword);
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener los usuarios', error });
    }
};

// Obtener un usuario por ID
export const obtenerUsuariobyId = async (req: Request, res: Response) => {
    try {
        const usuario = await UsuarioModel.obtenerPorId(req.params.id);
        // Omitir el password en la respuesta
        if (usuario) {
            const { password, ...usuarioSinPassword } = usuario;
            res.status(200).json(usuarioSinPassword);
        } else {
            res.status(404).json({ message: 'Usuario no encontrado' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener el usuario', error });
    }
};

// Actualizar un usuario
export const actualizarUsuario = async (req: Request, res: Response) => {
    try {
        const usuario = await UsuarioModel.actualizar(req.params.id, req.body) as any;
        // Omitir el password en la respuesta
        const { password, ...usuarioSinPassword } = usuario;
        res.status(200).json(usuarioSinPassword);
    } catch (error) {
        res.status(500).json({ message: 'Error al actualizar el usuario', error });
    }
}

// Eliminar un usuario
export const eliminarUsuario = async (req: Request, res: Response) => {
    try {
        await UsuarioModel.eliminar(req.params.id);
        res.status(200).json({ message: 'Usuario eliminado con éxito' });
        } catch (error) {
            res.status(500).json({ message: 'Error al eliminar el usuario', error });
    }
}; 

// Aplicar rate limiting a las rutas de login
export const loginUsuario = async (req: Request, res: Response, next: NextFunction) => {
    try {
        const usuario = await UsuarioModel.validarCredenciales(req.body.email, req.body.password);
        if (usuario) {
            // Nunca devolver el hash de la contraseña
            const { password, ...usuarioSinPassword } = usuario;
            res.status(200).json(usuarioSinPassword);
        } else {
            res.status(401).json({ message: 'Credenciales inválidas' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error en el login' });
    }
}

// Asegurar que ninguna ruta devuelva el hash de la contraseña
export const omitirPassword = async (req: Request, res: Response) => {
    try {
        const usuario = await UsuarioModel.obtenerPorId(req.params.id);
        if (usuario) {
            const { password, ...usuarioSinPassword } = usuario;
            res.json(usuarioSinPassword);
        } else {
            res.status(404).json({ message: 'Usuario no encontrado' });
        }
    } catch (error) {
        res.status(500).json({ message: 'Error al obtener usuario' });
    }
}



